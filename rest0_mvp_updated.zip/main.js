// React entry point placeholder
console.log('Rest 0 MVP loaded');